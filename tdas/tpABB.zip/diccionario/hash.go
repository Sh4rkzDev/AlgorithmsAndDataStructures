package diccionario

import (
	"fmt"
	TDALista "tdas/lista"
)

// https://golangprojectstructure.com/hash-functions-go-code/#how-are-hash-functions-used-in-the-map-data-structure
const (
	uint64Offset uint64 = 0xcbf29ce484222325
	uint64Prime  uint64 = 0x00000100000001b3
	tamInicial   int    = 11
	factorPred   int    = 10 / 9
)

func convertirABytes[K comparable](clave K) []byte {
	return []byte(fmt.Sprintf("%v", clave))
}

func hashing(data []byte) (hash uint64) {
	hash = uint64Offset

	for _, b := range data {
		hash ^= uint64(b)
		hash *= uint64Prime
	}

	return
}

type parClaveValor[K comparable, V any] struct {
	clave K
	valor V
}

type hashAbierto[K comparable, V any] struct {
	tabla []TDALista.Lista[*parClaveValor[K, V]]
	cant  int
}

type iteradorDiccionario[K comparable, V any] struct {
	dic      *hashAbierto[K, V]
	act      int
	actLista TDALista.Lista[*parClaveValor[K, V]]
	actPar   TDALista.IteradorLista[*parClaveValor[K, V]]
}

func CrearHash[K comparable, V any]() Diccionario[K, V] {
	return &hashAbierto[K, V]{tabla: make([]TDALista.Lista[*parClaveValor[K, V]], tamInicial)}
}

func (h *hashAbierto[K, V]) crearIterDiccionario() IterDiccionario[K, V] {
	iter := &iteradorDiccionario[K, V]{dic: h}
	for i, lista := range iter.dic.tabla {
		if lista == nil {
			continue
		}
		iter.act = i
		iter.actLista = lista
		iter.actPar = iter.actLista.Iterador()
		break
	}
	return iter
}

func crearParClaveValor[K comparable, V any](clave K, valor V) *parClaveValor[K, V] {
	return &parClaveValor[K, V]{clave, valor}
}

func obtenerPos[K comparable](clave K, tam int) uint64 {
	return hashing(convertirABytes(clave)) % uint64(tam)
}

func buscarSigPrimo(k int) int {
	for i := k; ; i++ {
		primo := true
		for j := 2; j*j <= i; j++ {
			if i%j == 0 {
				primo = false
				break
			}
		}
		if primo {
			return i
		}
	}
}

func (h *hashAbierto[K, V]) redimensionar(tam int) {
	nueva := make([]TDALista.Lista[*parClaveValor[K, V]], tam)
	for _, lista := range h.tabla {
		if lista == nil {
			continue
		}
		for iter := lista.Iterador(); iter.HaySiguiente(); iter.Siguiente() {
			par := iter.VerActual()
			pos := obtenerPos(par.clave, tam)
			if nueva[pos] == nil {
				nueva[pos] = TDALista.CrearListaEnlazada[*parClaveValor[K, V]]()
			}
			nueva[pos].InsertarUltimo(crearParClaveValor(par.clave, par.valor))
		}
	}
	h.tabla = nueva
}

func (h *hashAbierto[K, V]) Guardar(clave K, dato V) {
	pos := obtenerPos(clave, len(h.tabla))
	if h.tabla[pos] == nil {
		h.tabla[pos] = TDALista.CrearListaEnlazada[*parClaveValor[K, V]]()
	}
	for iter := h.tabla[pos].Iterador(); iter.HaySiguiente(); iter.Siguiente() {
		if iter.VerActual().clave != clave {
			continue
		}
		iter.VerActual().valor = dato
		return
	}
	h.tabla[pos].InsertarUltimo(crearParClaveValor(clave, dato))
	h.cant++
	if h.Cantidad()/len(h.tabla) >= 2 {
		h.redimensionar(buscarSigPrimo(h.Cantidad() * factorPred))
	}
}

func (h *hashAbierto[K, V]) Pertenece(clave K) bool {
	pos := obtenerPos(clave, len(h.tabla))
	if h.tabla[pos] == nil {
		return false
	}
	for iter := h.tabla[pos].Iterador(); iter.HaySiguiente(); iter.Siguiente() {
		if iter.VerActual().clave == clave {
			return true
		}
	}
	return false
}

func (h *hashAbierto[K, V]) Obtener(clave K) V {
	pos := obtenerPos(clave, len(h.tabla))
	if h.tabla[pos] == nil {
		panic("La clave no pertenece al diccionario")
	}
	for iter := h.tabla[pos].Iterador(); iter.HaySiguiente(); iter.Siguiente() {
		if iter.VerActual().clave == clave {
			return iter.VerActual().valor
		}
	}
	panic("La clave no pertenece al diccionario")
}

func (h *hashAbierto[K, V]) Borrar(clave K) V {
	pos := obtenerPos(clave, len(h.tabla))
	if h.tabla[pos] == nil {
		panic("La clave no pertenece al diccionario")
	}
	for iter := h.tabla[pos].Iterador(); iter.HaySiguiente(); iter.Siguiente() {
		if iter.VerActual().clave != clave {
			continue
		}
		par := iter.Borrar()
		h.cant--
		factor := float32(h.Cantidad()) / float32(len(h.tabla))
		aux := h.Cantidad() * factorPred
		if h.tabla[pos].Largo() == 0 {
			h.tabla[pos] = nil
		}
		if factor <= 0.2 && aux > tamInicial {
			h.redimensionar(buscarSigPrimo(aux))
		}
		return par.valor
	}
	panic("La clave no pertenece al diccionario")
}

func (h *hashAbierto[K, V]) Cantidad() int {
	return h.cant
}

func (h *hashAbierto[K, V]) Iterar(visitar func(clave K, dato V) bool) {
	for _, lista := range h.tabla {
		if lista == nil {
			continue
		}
		for iter := lista.Iterador(); iter.HaySiguiente(); iter.Siguiente() {
			if !visitar(iter.VerActual().clave, iter.VerActual().valor) {
				return
			}
		}
	}
}

func (h *hashAbierto[K, V]) Iterador() IterDiccionario[K, V] {
	return h.crearIterDiccionario()
}

func (iter *iteradorDiccionario[K, V]) HaySiguiente() bool {
	return iter.actLista != nil && iter.actPar.HaySiguiente()
}

func (iter *iteradorDiccionario[K, V]) VerActual() (K, V) {
	if !iter.HaySiguiente() {
		panic("El iterador termino de iterar")
	}
	return iter.actPar.VerActual().clave, iter.actPar.VerActual().valor
}

func (iter *iteradorDiccionario[K, V]) Siguiente() {
	if !iter.HaySiguiente() {
		panic("El iterador termino de iterar")
	}
	iter.actPar.Siguiente()
	if !iter.actPar.HaySiguiente() {
		for i := iter.act + 1; i < len(iter.dic.tabla); i++ {
			if iter.dic.tabla[i] != nil || len(iter.dic.tabla)-1 == i {
				iter.act = i
				iter.actLista = iter.dic.tabla[i]
				if iter.dic.tabla[i] != nil {
					iter.actPar = iter.actLista.Iterador()
				}
				return
			}
		}
	}
}
